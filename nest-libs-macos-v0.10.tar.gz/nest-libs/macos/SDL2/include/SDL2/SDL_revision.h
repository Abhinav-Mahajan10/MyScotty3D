#define SDL_REVISION "https://github.com/15-466/nest-libs@"
#define SDL_REVISION_NUMBER 0
